#include <iostream>
#include <unordered_map>
#include <string>
#include <stack>
#include <queue>
#include <list>

using namespace std;

// Book structure
struct Book {
    int id;
    string title;
    string author;
};

// User structure
struct User {
    int id;
    string name;
    vector<int> requestedBooks; // List of requested book IDs
};

// Node structure for a linked list
struct Node {
    Book book;
    Node* next;
};

// Linked list for storing books
class BookList {
private:
    Node* head;

public:
    BookList() : head(nullptr) {}

    void addBook(const Book& book) {
        Node* newNode = new Node{book, head};
        head = newNode;
    }

    void listBooks() {
        Node* current = head;
        while (current) {
            cout << "ID: " << current->book.id << ", Title: " << current->book.title << ", Author: " << current->book.author << endl;
            current = current->next;
        }
    }

    bool deleteBook(int bookId) {
        Node** current = &head;
        while (*current) {
            if ((*current)->book.id == bookId) {
                Node* toDelete = *current;
                *current = (*current)->next;
                delete toDelete;
                return true;
            }
            current = &((*current)->next);
        }
        return false;
    }

    bool searchBook(const string& title) {
        Node* current = head;
        bool found = false;
        while (current) {
            if (current->book.title.find(title) != string::npos) {
                cout << "ID: " << current->book.id << ", Title: " << current->book.title << ", Author: " << current->book.author << endl;
                found = true;
            }
            current = current->next;
        }
        return found;
    }

    ~BookList() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

class Library {
private:
    unordered_map<int, User> users; // Store users using their ID
    BookList bookList; // Linked list to store books
    stack<Book> actionStack; // Stack to undo actions
    queue<int> requestQueue; // Queue for book requests
    int bookIdCounter;
    int userIdCounter;

public:
    Library() : bookIdCounter(1), userIdCounter(1) {}

    // Add a book
    void addBook(const string& title, const string& author) {
        Book newBook = {bookIdCounter, title, author};
        bookList.addBook(newBook);
        actionStack.push(newBook); // Push the action onto the stack
        cout << "Book added successfully with ID: " << bookIdCounter << endl;
        bookIdCounter++;
    }

    // Undo the last action
    void undoLastAction() {
        if (actionStack.empty()) {
            cout << "No actions to undo." << endl;
            return;
        }
        Book lastBook = actionStack.top();
        actionStack.pop();
        bookList.deleteBook(lastBook.id);
        cout << "Undid the addition of book ID: " << lastBook.id << endl;
    }

    // Delete a book
    void deleteBook(int bookId) {
        if (bookList.deleteBook(bookId)) {
            cout << "Book with ID " << bookId << " deleted successfully." << endl;
        } else {
            cout << "Book with ID " << bookId << " not found." << endl;
        }
    }

    // List all books
    void listBooks() {
        if (bookIdCounter == 1) {
            cout << "No books available." << endl;
            return;
        }
        cout << "Books in the library:" << endl;
        bookList.listBooks();
    }

    // List all users
    void listUsers() {
        if (users.empty()) {
            cout << "No users registered." << endl;
            return;
        }

        cout << "Users in the system:" << endl;
        for (const auto& [id, user] : users) {
            cout << "ID: " << user.id << ", Name: " << user.name << endl;
        }
    }

    // Search for a book by title
    void searchBook(const string& title) {
        cout << "Search results for title: " << title << endl;
        if (!bookList.searchBook(title)) {
            cout << "No books found with the title containing: " << title << endl;
        }
    }

    // Request a book
    void requestBook(int userId, int bookId) {
        if (users.find(userId) == users.end()) {
            cout << "User  with ID " << userId << " does not exist." << endl;
            return;
        }

        users[userId].requestedBooks.push_back(bookId);
        requestQueue.push(bookId); // Add to the request queue
        cout << "Book with ID " << bookId << " has been requested by User ID " << userId << "." << endl;
    }

    // Process book requests
    void processRequests() {
        while (!requestQueue.empty()) {
            int bookId = requestQueue.front();
            requestQueue.pop();
            cout << "Processing request for Book ID: " << bookId << endl;
        }
    }

    // Register a user
    int registerUser (const string& name) {
        users[userIdCounter] = {userIdCounter, name, {}};
        cout << "User  registered successfully with ID: " << userIdCounter << endl;
        return userIdCounter++;
    }
};

int main() {
    Library library;
    int choice;

    while (true) {
        cout << "\nLogin as:\n1. Administrator\n2. User\n3. Exit\nChoice: ";
        cin >> choice;

        if (choice == 1) {
            // Administrator menu
            while (true) {
                cout << "\nAdministrator Menu:\n1. Add Book\n2. Delete Book\n3. List Users\n4. List Books\n5. Undo Last Action\n6. Process Requests\n7. Exit\nChoice: ";
                cin >> choice;

                if (choice == 1) {
                    string title, author;
                    cout << "Enter book title: ";
                    cin.ignore();
                    getline(cin, title);
                    cout << "Enter book author: ";
                    getline(cin, author);
                    library.addBook(title, author);
                } else if (choice == 2) {
                    int bookId;
                    cout << "Enter book ID to delete: ";
                    cin >> bookId;
                    library.deleteBook(bookId);
                } else if (choice == 3) {
                    library.listUsers();
                } else if (choice == 4) {
                    library.listBooks();
                } else if (choice == 5) {
                    library.undoLastAction();
                } else if (choice == 6) {
                    library.processRequests();
                } else if (choice == 7) {
                    break;
                } else {
                    cout << "Invalid choice." << endl;
                }
            }
        } else if (choice == 2) {
            // User menu
            string userName;
            int userId;

            cout << "Enter your name to register/login: ";
            cin.ignore();
            getline(cin, userName);
            userId = library.registerUser (userName);

            while (true) {
                cout << "\nUser  Menu:\n1. Search Book\n2. List Books\n3. Request Book\n4. Exit\nChoice: ";
                cin >> choice;

                if (choice == 1) {
                    string title;
                    cout << "Enter book title to search: ";
                    cin.ignore();
                    getline(cin, title);
                    library.searchBook(title);
                } else if (choice == 2) {
                    library.listBooks();
                } else if (choice == 3) {
                    int bookId;
                    cout << "Enter book ID to request: ";
                    cin >> bookId;
                    library.requestBook(userId, bookId);
                } else if (choice == 4) {
                    break;
                } else {
                    cout << "Invalid choice." << endl;
                }
            }
        } else if (choice == 3) {
            cout << "Exiting..." << endl;
            break;
        } else {
            cout << "Invalid choice." << endl;
        }
    }

    return 0;
}