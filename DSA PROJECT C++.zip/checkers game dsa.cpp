#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <stack>

using namespace std;

// ANSI color codes
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define MAGENTA "\033[35m"
#define CYAN    "\033[36m"
#define WHITE   "\033[37m"

// --- Graph Representation for Checkers ---
class CheckersGraph {
private:
    vector<vector<pair<int, int>>> adjacencyList;

public:
    CheckersGraph() {
        adjacencyList.resize(8 * 8); // 64 positions
        buildGraph();
    }

    void buildGraph() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 != 0) { // Only valid positions (black squares)
                    vector<pair<int, int>> neighbors;
                    // Add diagonal moves
                    if (i > 0 && j > 0) neighbors.push_back({i - 1, j - 1}); //TOPLEFT
                    if (i > 0 && j < 7) neighbors.push_back({i - 1, j + 1}); //TOPRIGHT
                    if (i < 7 && j > 0) neighbors.push_back({i + 1, j - 1}); //BOTTOMLEFT
                    if (i < 7 && j < 7) neighbors.push_back({i + 1, j + 1}); //BOTTOMRIGHT
                    adjacencyList[i * 8 + j] = neighbors; // Map position (i, j) to neighbors
                }
            }
        }
    }

    vector<pair<int, int>> getNeighbors(int row, int col) {
        return adjacencyList[row * 8 + col];
    }
};

// --- Linked List Node for Move History ---
struct MoveNode {
    int startX, startY, endX, endY;
    MoveNode* next;
    MoveNode(int sx, int sy, int ex, int ey)
        : startX(sx), startY(sy), endX(ex), endY(ey), next(nullptr) {}
};

// --- Linked List for Move History ---
class MoveHistory {
private:
    MoveNode* head;
public:
    MoveHistory() : head(nullptr) {}

    void addMove(int startX, int startY, int endX, int endY) {
        MoveNode* newNode = new MoveNode(startX, startY, endX, endY);
        newNode->next = head;
        head = newNode;
    }

    void printHistory() {
        MoveNode* current = head;
        while (current != nullptr) {
            cout << "(" << current->startX << "," << current->startY << ") -> "
                 << "(" << current->endX << "," << current->endY << ")" << endl;
            current = current->next;
        }
    }

    ~MoveHistory() {
        while (head) {
            MoveNode* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

// --- Custom Stack Implementation for Undo and Redo ---
template <typename T>
class CustomStack {
private:  
    struct Node {
        T data;
        Node* next;
        Node(const T& value) : data(value), next(nullptr) {}
    };

    Node* topNode;

public:
    CustomStack() : topNode(nullptr) {}

    void push(const T& value) {
        Node* newNode = new Node(value);
        newNode->next = topNode;
        topNode = newNode;
    }

    T pop() {
        if (topNode == nullptr) {
            throw out_of_range("Stack is empty!");
        }
        T topValue = topNode->data;
        Node* temp = topNode;
        topNode = topNode->next;
        delete temp;
        return topValue;
    }

    bool isEmpty() const {
        return topNode == nullptr;
    }

    T top() const {
        if (topNode == nullptr) {
            throw out_of_range("Stack is empty!");
        }
        return topNode->data;
    }

    ~CustomStack() {
        while (!isEmpty()) {
            pop();
        }
    }
};

// --- Custom Queue Implementation for Player Switching ---
template <typename T>
class CustomQueue {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& value) : data(value), next(nullptr) {}
    };

    Node* frontNode;
    Node* rearNode;

public:
    CustomQueue() : frontNode(nullptr), rearNode(nullptr) {}

    void enqueue(const T& value) {
        Node* newNode = new Node(value);
        if (rearNode == nullptr) {
            frontNode = rearNode = newNode;
            return;
        }
        rearNode->next = newNode;
        rearNode = newNode;
    }

    T dequeue() {
        if (frontNode == nullptr) {
            throw out_of_range("Queue is empty!");
        }
        T frontValue = frontNode->data;
        Node* temp = frontNode;
        frontNode = frontNode->next;
        if (frontNode == nullptr) {
            rearNode = nullptr; // Queue becomes empty
        }
        delete temp;
        return frontValue;
    }

    T front() const {
        if (frontNode == nullptr) {
            throw out_of_range("Queue is empty!");
        }
        return frontNode->data;
    }

    bool isEmpty() const {
        return frontNode == nullptr;
    }

    ~CustomQueue() {
        while (!isEmpty()) {
            dequeue();
        }
    }
};

// --- Game State ---
class GameState {
public:
    vector<vector<char>> board;
    string player1, player2;
    char currentPlayer;
    CheckersGraph graph;

    GameState() {
        board = vector<vector<char>>(8, vector<char>(8, '-'));
        currentPlayer = 'X'; // Player X starts

        // Initialize the board with pieces
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 != 0) {
                    if (i < 3) board[i][j] = 'X';  // Player X's pieces
                    else if (i > 4) board[i][j] = 'O'; // Player O's pieces
                }
            }
        }
    }

    void printBoard() {
        cout << "  0 1 2 3 4 5 6 7" << endl;
        for (int i = 0; i < 8; i++) {
            cout << i << " ";
            for (int j = 0; j < 8; j++) {
                if (board[i][j] == 'X') {
                    cout << RED << board[i][j] << RESET << " ";
                } else if (board[i][j] == 'O') {
                    cout << BLUE << board[i][j] << RESET << " ";
                } else {
                    cout << WHITE << board[i][j] << RESET << " ";
                }
            }
            cout << endl;
        }
    }

    bool isValidMoveDirection(int startX, int startY, int endX, int endY) {
        if (currentPlayer == 'X') {
            return endX > startX; // X moves down
        } else if (currentPlayer == 'O') {
            return endX < startX; // O moves up
        }
        return false;
    }

    bool isValidMove(int startX, int startY, int endX, int endY) {
        if (board[endX][endY] != '-') return false;
        if (!isValidMoveDirection(startX, startY, endX, endY)) return false;

        vector<pair<int, int>> neighbors = graph.getNeighbors(startX, startY);
        for (auto& neighbor : neighbors) {
            if (neighbor.first == endX && neighbor.second == endY) {
                return true;
            }
        }
        return false;
    }

    bool isJumpMove(int startX, int startY, int endX, int endY) {
        if (abs(startX - endX) == 2 && abs(startY - endY) == 2) {
            int midX = (startX + endX) / 2;
            int midY = (startY + endY) / 2;
            if (board[midX][midY] != '-' && board[midX][midY] != currentPlayer && board[endX][endY] == '-') {
                return true;
            }
        }
        return false;
    }

    void removeOpponentPiece(int startX, int startY, int endX, int endY) {
        int midX = (startX + endX) / 2;
        int midY = (startY + endY) / 2;
        if (board[midX][midY] != '-' && board[midX][midY] != currentPlayer) {
            board[midX][midY] = '-';
        }
    }

    vector<pair<int, int>> getAvailableMoves(int startX, int startY) {
        vector<pair<int, int>> availableMoves;
        if (board[startX][startY] == currentPlayer) {
            vector<pair<int, int>> neighbors = graph.getNeighbors(startX, startY);
            for (auto& neighbor : neighbors) {
                int endX = neighbor.first, endY = neighbor.second;
                if (board[endX][endY] == '-') {
                    if (isValidMoveDirection(startX, startY, endX, endY)) {
                        availableMoves.push_back({endX, endY});
                    }
                }
                if (abs(startX - endX) == 2 && abs(startY - endY) == 2) {
                    int midX = (startX + endX) / 2;
                    int midY = (startY + endY) / 2;
                    if (board[endX][endY] == '-' && board[midX][midY] != '-' && board[midX][midY] != currentPlayer) {
                        availableMoves.push_back({endX, endY});
                    }
                }
            }
        }
        return availableMoves;
    }
};

// --- Checkers Game ---
class CheckersGame {
private:

    MoveHistory moveHistory;
    GameState currentState;
    CustomQueue<char> playerQueue;

public:
    CheckersGame() {
        playerQueue.enqueue('X');
        playerQueue.enqueue('O');
    }

    void startNewGame() {
        currentState = GameState();

        cout << GREEN << "New Game Started!" << RESET << endl;
    }

    void makeMove(int startX, int startY, int endX, int endY) {
        if (currentState.isJumpMove(startX, startY, endX, endY)) {
            currentState.removeOpponentPiece(startX, startY, endX, endY);
            currentState.board[endX][endY] = currentState.board[startX][startY];
            currentState.board[startX][startY] = '-';
  
            playerQueue.dequeue();
            playerQueue.enqueue(currentState.currentPlayer);
            currentState.currentPlayer = playerQueue.front();
            moveHistory.addMove(startX, startY, endX, endY);
            cout << GREEN << "Jump move made!" << RESET << endl;
        } else if (currentState.isValidMove(startX, startY, endX, endY)) {
            currentState.board[endX][endY] = currentState.board[startX][startY];
            currentState.board[startX][startY] = '-';
       
            playerQueue.dequeue();
            playerQueue.enqueue(currentState.currentPlayer);
            currentState.currentPlayer = playerQueue.front();
            moveHistory.addMove(startX, startY, endX, endY);
            cout << GREEN << "Move made!" << RESET << endl;
        } else {
            cout << RED << "Invalid move!" << RESET << endl;
        }
    }

    void displayGameState() {
        currentState.printBoard();
        cout << "Current Player: " << currentState.currentPlayer << endl;
        cout << "Move History: ";
        moveHistory.printHistory();
        cout << endl;
    }

    void displayAvailableMoves(int startX, int startY) {
        vector<pair<int, int>> moves = currentState.getAvailableMoves(startX, startY);
        if (moves.empty()) {
            cout << RED << "No available moves!" << RESET << endl;
        } else {
            cout << GREEN << "Available Moves for (" << startX << ", " << startY << "):" << RESET << endl;
            for (auto& move : moves) {
                cout << "(" << move.first << ", " << move.second << ")" << endl;
            }
        }
    }

    void runGame() {
        while (true) {
            system("cls");
            displayGameState();
            cout << "\nSelect option:" << endl;
            cout << CYAN << "1. Start New Game" << RESET << endl;
            cout << CYAN << "2. Make a Move" << RESET << endl;
    
            cout << CYAN << "3. Exit" << RESET << endl;

            int choice;
            cin >> choice;

            switch (choice) {
                case 1:
                    startNewGame();
                    break;
                case 2: {
                    int startX, startY, endX, endY;
                    cout << "Enter current piece coordinates (row column): ";
                    cin >> startX >> startY;
                    displayAvailableMoves(startX, startY);
                    cout << "Enter target coordinates (row column): ";
                    cin >> endX >> endY;
                    system("cls");
                    makeMove(startX, startY, endX, endY);
                    break;
                }
           
                case 3:
                    cout << GREEN << "Exiting game!" << RESET << endl;
                    return;
            }
        }
    }
};

int main() {
    CheckersGame game;
    game.runGame();
}