#include <iostream>
#include <cstdlib>  // For system("clear") and system("CLS")
#include <algorithm>  // For sort algorithms
#include <vector>  // To use std::vector for sorting
#include <stdexcept>  // For runtime_error
using namespace std;

// Task class to represent a task
class Task {
public:
    int id;
    string name;
    int priority; // Lower number means higher priority
    string dueDate; // Format: YYYY-MM-DD

    Task(int id, string name, int priority, string dueDate)
        : id(id), name(name), priority(priority), dueDate(dueDate) {}
};

// Stack Implementation using Bubble Sort
class Stack {
private:
    vector<Task> tasks;

public:
    void push(Task task) {
        tasks.push_back(task);
    }

    void pop() {
        if (tasks.empty()) {
            cout << "No tasks to pop\n";
            return;
        }
        tasks.pop_back();
    }

    Task peek() const {
        if (tasks.empty()) {
            throw runtime_error("No tasks in stack");
        }
        return tasks.back();
    }

    bool isEmpty() const {
        return tasks.empty();
    }

    void clear() {
        tasks.clear();
        cout << "Stack cleared\n";
    }

    void display() const {
        if (tasks.empty()) {
            cout << "Stack is empty\n";
            return;
        }
        for (const auto& task : tasks) {
            cout << "ID: " << task.id << ", Name: " << task.name 
                 << ", Priority: " << task.priority << ", Due Date: " << task.dueDate << "\n";
        }
    }

    void insertMultiple() {
        int n, id, priority;
        string name, dueDate;
        cout << "Enter the number of tasks to push: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            cout << "Enter task ID: ";
            cin >> id;
            cout << "Enter task name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter task priority: ";
            cin >> priority;
            cout << "Enter task due date (YYYY-MM-DD): ";
            cin >> dueDate;
            push(Task(id, name, priority, dueDate));
        }
    }

    // Bubble Sort for Stack
    void sortStack() {
        sort(tasks.begin(), tasks.end(), [](const Task& a, const Task& b) {
            return a.priority < b.priority;
        });
        cout << "Stack sorted by priority\n";
    }
};

// Node for Linked List and Tree
class Node {
public:
    Task task;
    Node* next;
    Node* left;
    Node* right;

    Node(Task task) : task(task), next(nullptr), left(nullptr), right(nullptr) {}
};

// Linked List Implementation using Insertion Sort
class LinkedList {
private:
    Node* head;

public:
    LinkedList() : head(nullptr) {}

    ~LinkedList() {
        clear();
    }

    void insert(Task task) {
        Node* newNode = new Node(task);
        newNode->next = head;
        head = newNode;
    }

    void remove(int id) {
        if (!head) {
            cout << "Linked List is empty\n";
            return;
        }
        if (head->task.id == id) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        Node* temp = head;
        while (temp->next && temp->next->task.id != id) {
            temp = temp->next;
        }
        if (temp->next) {
            Node* toDelete = temp->next;
            temp->next = temp->next->next;
            delete toDelete;
        } else {
            cout << "Task with ID " << id << " not found\n";
        }
    }

    bool search(int id) const {
        Node* temp = head;
        while (temp) {
            if (temp->task.id == id) {
                return true;
            }
            temp = temp->next;
        }
        return false;
    }

    void clear() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        cout << "Linked List cleared\n";
    }

    void display() const {
        Node* temp = head;
        while (temp) {
            cout << "ID: " << temp->task.id << ", Name: " << temp->task.name 
                 << ", Priority: " << temp->task.priority << ", Due Date: " << temp->task.dueDate << "\n";
            temp = temp->next;
        }
    }

    void insertMultiple() {
        int n, id, priority;
        string name, dueDate;
        cout << "Enter the number of tasks to insert: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            cout << "Enter task ID: ";
            cin >> id;
            cout << "Enter task name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter task priority: ";
            cin >> priority;
            cout << "Enter task due date (YYYY-MM-DD): ";
            cin >> dueDate;
            insert(Task(id, name, priority, dueDate));
        }
    }

    // Insertion Sort for Linked List by Due Date
    void sortLinkedList() {
        if (!head || !head->next) return;

        Node* sorted = nullptr;

        while (head) {
            Node* current = head;
            head = head->next;

            if (!sorted || sorted->task.dueDate >= current->task.dueDate) {
                current->next = sorted;
                sorted = current;
            } else {
                Node* temp = sorted;
                while (temp->next && temp->next->task.dueDate < current->task.dueDate) {
                    temp = temp->next;
                }
                current->next = temp->next;
                temp->next = current;
            }
        }

        head = sorted;
        cout << "Linked List sorted by due date\n";
    }
};

// Binary Tree Implementation (already inherently sorted)
class BinaryTree {
private:
    Node* root;

    void insertHelper(Node*& node, Task task) {
        if (!node) {
            node = new Node(task);
        } else if (task.priority < node->task.priority) {
            insertHelper(node->left, task);
        } else {
            insertHelper(node->right, task);
        }
    }

    void inorderHelper(Node* node) const {
        if (node) {
            inorderHelper(node->left);
            cout << "ID: " << node->task.id << ", Name: " << node->task.name 
                 << ", Priority: " << node->task.priority << ", Due Date: " << node->task.dueDate << "\n";
            inorderHelper(node->right);
        }
    }

    void preorderHelper(Node* node) const {
        if (node) {
            cout << "ID: " << node->task.id << ", Name: " << node->task.name 
                 << ", Priority: " << node->task.priority << ", Due Date: " << node->task.dueDate << "\n";
            preorderHelper(node->left);
            preorderHelper(node->right);
        }
    }

    void postorderHelper(Node* node) const {
        if (node) {
            postorderHelper(node->left);
            postorderHelper(node->right);
            cout << "ID: " << node->task.id << ", Name: " << node->task.name 
                 << ", Priority: " << node->task.priority << ", Due Date: " << node->task.dueDate << "\n";
        }
    }

    Node* searchHelper(Node* node, int id) const {
        if (!node || node->task.id == id) {
            return node;
        }
        if (id < node->task.id) {
            return searchHelper(node->left, id);
        }
        return searchHelper(node->right, id);
    }

public:
    BinaryTree() : root(nullptr) {}

    ~BinaryTree() {
        clear(root);
    }

    void insert(Task task) {
        insertHelper(root, task);
    }

    bool search(int id) const {
        return searchHelper(root, id) != nullptr;
    }

    void displayInOrder() const {
        inorderHelper(root);
        cout << "\n";
    }

    void displayPreOrder() const {
        preorderHelper(root);
        cout << "\n";
    }

    void displayPostOrder() const {
        postorderHelper(root);
        cout << "\n";
    }

    void clear(Node* node) {
        if (node) {
            clear(node->left);
            clear(node->right);
            delete node;
        }
    }

    void insertMultiple() {
        int n, id, priority;
        string name, dueDate;
        cout << "Enter the number of tasks to insert: ";
        cin >> n;
        for (int i = 0; i < n; i++) {
            cout << "Enter task ID: ";
            cin >> id;
            cout << "Enter task name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter task priority: ";
            cin >> priority;
            cout << "Enter task due date (YYYY-MM-DD): ";
            cin >> dueDate;
            insert(Task(id, name, priority, dueDate));
        }
    }
};

// Function to clear the screen
void clearScreen() {
#if defined(_WIN32) || defined(_WIN64)
    system("CLS");
#else
    system("clear");
#endif
}

// Main function to demonstrate usage of data structures
int main() {
    Stack completedTasks;
    LinkedList taskList;
    BinaryTree taskTree;

    int choice, id, priority;
    string name, dueDate;

    while (true) {
        clearScreen();  // Clear the screen before displaying the menu
        cout << "\nTask Manager Menu:\n";
        cout << "1. Stack Operations (Completed Tasks)\n";
        cout << "2. Linked List Operations (Task List)\n";
        cout << "3. Binary Tree Operations (Priority Tasks)\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            clearScreen();
            cout << "\nCompleted Tasks (Stack) Operations:\n";
            cout << "1. Push Task\n";
            cout << "2. Pop Task\n";
            cout << "3. Peek Task\n";
            cout << "4. Display Tasks\n";
            cout << "5. Clear Tasks\n";
            cout << "6. Insert Multiple Tasks\n";
            cout << "7. Sort Tasks by Priority\n";
            cout << "Enter your choice: ";
            cin >> choice;
            switch (choice) {
            case 1:
                cout << "Enter task ID: ";
                cin >> id;
                cout << "Enter task name: ";
                cin.ignore();
                getline(cin, name);
                cout << "Enter task priority: ";
                cin >> priority;
                cout << "Enter task due date (YYYY-MM-DD): ";
                cin >> dueDate;
                completedTasks.push(Task(id, name, priority, dueDate));
                break;
            case 2:
                completedTasks.pop();
                break;
            case 3:
                try {
                    Task task = completedTasks.peek();
                    cout << "Top Task - ID: " << task.id << ", Name: " << task.name 
                         << ", Priority: " << task.priority << ", Due Date: " << task.dueDate << "\n";
                } catch (const runtime_error& e) {
                    cout << e.what() << "\n";
                }
                break;
            case 4:
                completedTasks.display();
                break;
            case 5:
                completedTasks.clear();
                break;
            case 6:
                completedTasks.insertMultiple();
                break;
            case 7:
                completedTasks.sortStack();
                break;
            }
            break;

        case 2:
            clearScreen();
            cout << "\nTask List (Linked List) Operations:\n";
            cout << "1. Insert Task\n";
            cout << "2. Remove Task\n";
            cout << "3. Search Task\n";
            cout << "4. Display Tasks\n";
            cout << "5. Clear Tasks\n";
            cout << "6. Insert Multiple Tasks\n";
            cout << "7. Sort Tasks by Due Date\n";
            cout << "Enter your choice: ";
            cin >> choice;
            switch (choice) {
            case 1:
                cout << "Enter task ID: ";
                cin >> id;
                cout << "Enter task name: ";
                cin.ignore();
                getline(cin, name);
                cout << "Enter task priority: ";
                cin >> priority;
                cout << "Enter task due date (YYYY-MM-DD): ";
                cin >> dueDate;
                taskList.insert(Task(id, name, priority, dueDate));
                break;
            case 2:
                cout << "Enter task ID to remove: ";
                cin >> id;
                taskList.remove(id);
                break;
            case 3:
                cout << "Enter task ID to search: ";
                cin >> id;
                if (taskList.search(id)) {
                    cout << "Task found\n";
                } else {
                    cout << "Task not found\n";
                }
                break;
            case 4:
                taskList.display();
                break;
            case 5:
                taskList.clear();
                break;
            case 6:
                taskList.insertMultiple();
                break;
            case 7:
                taskList.sortLinkedList();
                break;
            }
            break;

        case 3:
            clearScreen();
            cout << "\nPriority Tasks (Binary Tree) Operations:\n";
            cout << "1. Insert Task\n";
            cout << "2. Search Task\n";
            cout << "3. Display Tasks In-Order\n";
            cout << "4. Display Tasks Pre-Order\n";
            cout << "5. Display Tasks Post-Order\n";
            cout << "6. Insert Multiple Tasks\n";
            cout << "Enter your choice: ";
            cin >> choice;
            switch (choice) {
            case 1:
                cout << "Enter task ID: ";
                cin >> id;
                cout << "Enter task name: ";
                cin.ignore();
                getline(cin, name);
                cout << "Enter task priority: ";
                cin >> priority;
                cout << "Enter task due date (YYYY-MM-DD): ";
                cin >> dueDate;
                taskTree.insert(Task(id, name, priority, dueDate));
                break;
            case 2:
                cout << "Enter task ID to search: ";
                cin >> id;
                if (taskTree.search(id)) {
                    cout << "Task found\n";
                } else {
                    cout << "Task not found\n";
                }
                break;
            case 3:
                taskTree.displayInOrder();
                break;
            case 4:
                taskTree.displayPreOrder();
                break;
            case 5:
                taskTree.displayPostOrder();
                break;
            case 6:
                taskTree.insertMultiple();
                break;
            }
            break;

        case 4:
            exit(0);

        default:
            cout << "Invalid choice, please try again.\n";
        }
        // Pause to let the user see the result of their operation
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    return 0;
}