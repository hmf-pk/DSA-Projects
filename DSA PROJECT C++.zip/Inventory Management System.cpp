#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <functional> // For hash

using namespace std;

// Node for Linked List
struct Node {
    string data;
    Node* next;
    Node(const string& value) : data(value), next(NULL) {}
};

// Custom Stack class implementation using Linked List
class Stack {
private:
    Node* topNode;

public:
    Stack() : topNode(NULL) {}

    void push(const string& value) {
        Node* newNode = new Node(value);
        newNode->next = topNode;
        topNode = newNode;
    }

    void pop() {
        if (topNode) {
            Node* temp = topNode;
            topNode = topNode->next;
            delete temp;
        } else {
            cout << "Stack is empty!" << endl;
        }
    }

    string top() const {
        if (topNode) {
            return topNode->data;
        } else {
            return "Stack is empty!";
        }
    }

    bool empty() const {
        return topNode == NULL;
    }
};

// Custom Queue class implementation using Linked List
class Queue {
private:
    Node* frontNode;
    Node* rearNode;

public:
    Queue() : frontNode(NULL), rearNode(NULL) {}

    void push(const string& value) {
        Node* newNode = new Node(value);
        if (!rearNode) {
            frontNode = rearNode = newNode;
        } else {
            rearNode->next = newNode;
            rearNode = newNode;
        }
    }

    void pop() {
        if (frontNode) {
            Node* temp = frontNode;
            frontNode = frontNode->next;
            if (!frontNode) {
                rearNode = NULL;
            }
            delete temp;
        } else {
            cout << "Queue is empty!" << endl;
        }
    }

    string front() const {
        if (frontNode) {
            return frontNode->data;
        } else {
            return "Queue is empty!";
        }
    }

    bool empty() const {
        return frontNode == NULL;
    }
};

// Product Graph class with DFS traversal
class ProductGraph {
private:
    unordered_map<string, vector<string>> graph;
    hash<string> hasher; // Hash function

    void dfsUtil(const string& product, unordered_map<string, bool>& visited) {
        visited[product] = true;
        cout << product << " ";
        for (const auto& relatedProduct : graph[product]) {
            if (!visited[relatedProduct]) {
                dfsUtil(relatedProduct, visited);
            }
        }
    }

public:
    void addRelation(const string& product1, const string& product2) {
        graph[product1].push_back(product2);
        graph[product2].push_back(product1);
        cout << "Hash for " << product1 << ": " << hasher(product1) << endl;
        cout << "Hash for " << product2 << ": " << hasher(product2) << endl;
        cout << "Relation added between " << product1 << " and " << product2 << "." << endl;
    }

    void deleteRelation(const string& product1, const string& product2) {
        auto& vec1 = graph[product1];
        auto& vec2 = graph[product2];

        vec1.erase(remove(vec1.begin(), vec1.end(), product2), vec1.end());
        vec2.erase(remove(vec2.begin(), vec2.end(), product1), vec2.end());

        cout << "Relation deleted between " << product1 << " and " << product2 << "." << endl;
    }

    void showRelationsDFS(const string& product) {
        if (graph.find(product) == graph.end()) {
            cout << "No relations found for " << product << endl;
            return;
        }

        unordered_map<string, bool> visited;
        cout << "DFS Traversal starting from " << product << ":\n";
        dfsUtil(product, visited);
        cout << endl;
    }
};

// Restocking Queue class for managing requests
class RestockingQueue {
private:
    Queue queue;

public:
    void addRestockingRequest(const string& product) {
        queue.push(product);
        cout << "Added restocking request for " << product << "." << endl;
    }

    void processRestockingRequest() {
        if (!queue.empty()) {
            cout << "Restocking: " << queue.front() << endl;
            queue.pop();
        } else {
            cout << "No restocking requests." << endl;
        }
    }

    void showRestockingQueue() {
        cout << "Restocking Queue: ";
        Queue tempQueue = queue;
        while (!tempQueue.empty()) {
            cout << tempQueue.front() << " ";
            tempQueue.pop();
        }
        cout << endl;
    }
};

// Inventory System
class InventorySystem {
private:
    Stack actionStack;
    ProductGraph productGraph;
    RestockingQueue restockingQueue;
    vector<string> inventory;
    hash<string> hasher; // Hash function

public:
    void addProduct(const string& productName) {
        inventory.push_back(productName);
        actionStack.push("Added product: " + productName);
        cout << productName << " added to inventory with hash: " << hasher(productName) << "!" << endl;
    }

    void deleteProduct(const string& productName) {
        auto it = find(inventory.begin(), inventory.end(), productName);
        if (it != inventory.end()) {
            inventory.erase(it);
            actionStack.push("Deleted product: " + productName);
            cout << productName << " removed from inventory!" << endl;
        } else {
            cout << "Product not found!" << endl;
        }
    }

    void showAllProducts() {
        cout << "\nCurrent Products in Inventory:\n";
        for (const string& product : inventory) {
            cout << product << " (Hash: " << hasher(product) << ")" << endl;
        }
        actionStack.push("Showed all products");
    }

    void showRelatedProducts(const string& product) {
        productGraph.showRelationsDFS(product);
    }

    void addRestockingRequest(const string& product) {
        restockingQueue.addRestockingRequest(product);
    }

    void processRestocking() {
        restockingQueue.processRestockingRequest();
    }

    void showRestockingQueue() {
        restockingQueue.showRestockingQueue();
    }

    void undoLastAction() {
        if (!actionStack.empty()) {
            cout << "Undoing last action: " << actionStack.top() << endl;
            actionStack.pop();
        } else {
            cout << "No actions to undo." << endl;
        }
    }

    void addRelation(const string& product1, const string& product2) {
        productGraph.addRelation(product1, product2);
    }

    void deleteRelation(const string& product1, const string& product2) {
        productGraph.deleteRelation(product1, product2);
    }
};

// Function to display menu and handle user interaction
void displayMenu() {
    cout << "\n====== Aura Attire Inventory Management System ======\n";
    cout << "1. Add Product\n";
    cout << "2. Delete Product\n";
    cout << "3. Show All Products\n";
    cout << "4. Show Related Products\n";
    cout << "5. Add Restocking Request\n";
    cout << "6. Process Restocking\n";
    cout << "7. Show Restocking Queue\n";
    cout << "8. Undo Last Action\n";
    cout << "9. Add Product Relation\n";
    cout << "10. Delete Product Relation\n";
    cout << "0. Exit\n";
    cout << "=====================================================\n";
    cout << "Choose an option: ";
}

int main() {
    InventorySystem inventorySystem;

    // Adding initial products
    inventorySystem.addProduct("Shirt");
    inventorySystem.addProduct("Pants");
    inventorySystem.addProduct("Jacket");
    inventorySystem.addProduct("Shoes");
    inventorySystem.addProduct("Hat");

    // Adding predefined relations
    inventorySystem.addRelation("Shirt", "Pants");
    inventorySystem.addRelation("Shirt", "Jacket");
    inventorySystem.addRelation("Pants", "Shoes");
    inventorySystem.addRelation("Hat", "Jacket");
    


    int choice;
    string product, product1, product2;

    do {
        displayMenu();
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter product name to add: ";
                cin.ignore();
                getline(cin, product);
                inventorySystem.addProduct(product);
                break;
            case 2:
                cout << "Enter product name to delete: ";
                cin.ignore();
                getline(cin, product);
                inventorySystem.deleteProduct(product);
                break;
            case 3:
                inventorySystem.showAllProducts();
                break;
            case 4:
                cout << "Enter product name to show related products: ";
                cin.ignore();
                getline(cin, product);
                inventorySystem.showRelatedProducts(product);
                break;
            case 5:
                cout << "Enter product name to restock: ";
                cin.ignore();
                getline(cin, product);
                inventorySystem.addRestockingRequest(product);
                break;
            case 6:
                inventorySystem.processRestocking();
                break;
            case 7:
                inventorySystem.showRestockingQueue();
                break;
            case 8:
                inventorySystem.undoLastAction();
                break;
            case 9:
                cout << "Enter first product name for relation: ";
                cin.ignore();
                getline(cin, product1);
                cout << "Enter second product name for relation: ";
                getline(cin, product2);
                inventorySystem.addRelation(product1, product2);
                break;
            case 10:
                cout << "Enter first product name to delete relation: ";
                cin.ignore();
                getline(cin, product1);
                cout << "Enter second product name to delete relation: ";
                getline(cin, product2);
                inventorySystem.deleteRelation(product1, product2);
                break;
            case 0:
                cout << "Exiting system...\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }

        if (choice != 0) {
            cout << "\nPress Enter to go to the next screen...\n";
            cin.ignore();
            cin.get();
        }

    } while (choice != 0);

    return 0;
}
