#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <ctime>
#include <list>
#include <algorithm>
#include <iomanip>
#include <cstdlib> // Include this for system()
#include <stack>   // Include for stack

using namespace std;

struct AttendanceRecord {
    string date;
    string day;
    bool isPresent;
};

struct Guard {
    int id;
    string name;
    string contact;
    string shiftPreference;
    bool availability;
    int performanceRating;
    double salary;
    string weapon;
    int uniformItems;
    string cnic;
    vector<AttendanceRecord> attendance;
    Guard* next;

    // For BST
    Guard* left;  // Left child for BST
    Guard* right; // Right child for BST
};

class GuardManagement {
public:
    Guard* head; // Head of the linked list
    Guard* root; // Root of the BST
    stack<string> actionHistory; // Stack to keep track of actions

    GuardManagement() { 
        head = nullptr; 
        root = nullptr; 
    }

    void addGuard(int id, string name, string contact, string shift, bool available, int rating, double salary, string weapon, int uniformItems, string cnic) {
        Guard* newGuard = new Guard{id, name, contact, shift, available, rating, salary, weapon, uniformItems, cnic, {}, nullptr, nullptr, nullptr};
        
        // Add to linked list
        if (!head) {
            head = newGuard;
        } else {
            Guard* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newGuard;
        }

        // Add to BST
        root = insertGuard(root, newGuard);
        actionHistory.push("Added Guard ID: " + to_string(id));
    }

    Guard* insertGuard(Guard* node, Guard* newGuard) {
        if (node == nullptr) {
            return newGuard; // Insert here
        }
        if (newGuard->id < node->id) {
            node->left = insertGuard(node->left, newGuard); // Go left
        } else {
            node->right = insertGuard(node->right, newGuard); // Go right
        }
        return node; // Return the unchanged node pointer
    }

    void displayGuardData() {
        if (!head) {
            cout << "No guards available." << endl;
            return;
        }
        cout << "\n--- Guard Data ---" << endl;
        cout << left << setw(10) << "Guard ID" 
             << setw(20) << "Name" 
             << setw(15) << "Contact" 
             << setw(15) << "Shift" 
             << setw(12) << "Available" 
             << setw(10) << "Rating" 
             << setw(10) << "Salary" 
             << setw(15) << "Weapon" 
             << setw(15) << "Uniform Items" 
             << setw(15) << "CNIC" << endl;
        cout << string(130, '-') << endl;

        Guard* temp = head;
        while (temp) {
            cout << left << setw(10) << temp->id 
                 << setw(20) << temp->name 
                 << setw(15) << temp->contact
                 << setw(15) << temp->shiftPreference 
                 << setw(12) << (temp->availability ? "Yes" : "No")
                 << setw(10) << temp->performanceRating 
                 << setw(10) << fixed << setprecision(2) << temp->salary 
                 << setw(15) << temp->weapon 
                 << setw(15) << temp->uniformItems 
                 << setw(15) << temp->cnic << endl;
            temp = temp->next;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void scheduleShifts(string shift) {
        if (!head) {
            cout << "No guards available." << endl;
            return;
        }
        bool found = false;
        Guard* temp = head;
        cout << "\n--- Guards Scheduled for the " << shift << " Shift ---" << endl;
        while (temp) {
            if (temp->availability && temp->shiftPreference == shift) {
                cout << "Guard ID: " << temp->id << ", Name: " << temp->name << endl;
                found = true;
            }
            temp = temp->next;
        }
        if (!found) {
            cout << "No guards available for the " << shift << " shift." << endl;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void markAttendance(int guardID, bool isPresent) {
        Guard* temp = head;
        while (temp) {
            if (temp->id == guardID) {
                time_t t = time(0);
                tm* now = localtime(&t);
                char date[11];
                strftime(date, sizeof(date), "%Y-%m-%d", now);
                char day[10];
                strftime(day, sizeof(day), "%A", now);

                AttendanceRecord record = {date, day, isPresent};
                temp->attendance.push_back(record);
                cout << "Attendance for Guard ID " << guardID << " has been marked as " 
                     << (isPresent ? "Present" : "Absent") << " on " << date << " (" << day << ")" << endl;

                // Save attendance to file
                saveAttendanceToFile(guardID, record);
                return;
            }
            temp = temp->next;
        }
        cout << "Guard ID not found." << endl;
    }

    void saveAttendanceToFile(int guardID, const AttendanceRecord& record) {
        ofstream file("attendance.txt", ios::app);
        if (file.is_open()) {
            file << guardID << "," << record.date << "," << record.day << "," << record.isPresent << endl;
            file.close();
        } else {
            cout << "Error opening attendance file!" << endl;
        }
    }

    void loadAttendanceFromFile() {
        ifstream file("attendance.txt");
        if (!file.is_open()) {
            cout << "Could not open the attendance file!" << endl;
            return;
        }

        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            int guardID;
            string date, day;
            bool isPresent;

            getline(ss, line, ',');
            guardID = stoi(line);
            getline(ss, date, ',');
            getline(ss, day, ',');
            getline(ss, line, ',');
            isPresent = (line == "1");

            // Find the guard and add the attendance record
            Guard* temp = head;
            while (temp) {
                if (temp->id == guardID) {
                    AttendanceRecord record = {date, day, isPresent};
                    temp->attendance.push_back(record);
                    break;
                }
                temp = temp->next;
            }
        }
        file.close();
    }

    void updatePerformance(int guardID, int rating) {
        if (rating < 1 || rating > 5) {
            cout << "Invalid performance rating! Please enter a rating between 1 and 5." << endl;
            return;
        }

        Guard* temp = head;
        while (temp) {
            if (temp->id == guardID) {
                temp->performanceRating = rating;
                cout << "Performance rating for Guard ID " << guardID << " has been updated to " << rating << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "Guard ID not found." << endl;
    }

    void saveToFile(const string& filename) {
        ofstream file(filename);
        Guard* temp = head;
        while (temp) {
            file << temp->id << "," << temp->name << "," << temp->contact << "," << temp->shiftPreference << "," 
                 << temp->availability << "," << temp->performanceRating << "," << temp->salary << "," 
                 << temp->weapon << "," << temp->uniformItems << "," << temp->cnic << endl;
            temp = temp->next;
        }
        file.close();
    }

    void loadFromFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Could not open the file!" << endl;
            return;
        }

        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            Guard* newGuard = new Guard();
            string availability;

            getline(ss, availability, ',');
            newGuard->id = stoi(availability);
            getline(ss, newGuard->name, ',');
            getline(ss, newGuard->contact, ',');
            getline(ss, newGuard->shiftPreference, ',');
            getline(ss, availability, ',');
            newGuard->availability = (availability == "1");
            getline(ss, availability, ',');
            newGuard->performanceRating = stoi(availability);
            getline(ss, availability, ',');
            newGuard->salary = stod(availability);
            getline(ss, newGuard->weapon, ',');
            getline(ss, availability, ',');
            newGuard->uniformItems = stoi(availability);
            getline(ss, newGuard->cnic, ',');

            // Add to linked list
            if (!head) {
                head = newGuard;
            } else {
                Guard* temp = head;
                while (temp->next) {
                    temp = temp->next;
                }
                temp->next = newGuard;
            }

            // Add to BST
            root = insertGuard(root, newGuard);
        }
        file.close();
    }

    void searchAttendanceByGuardID(int guardID) {
        Guard* temp = head;
        while (temp) {
            if (temp->id == guardID) {
                cout << "Attendance Records for Guard ID " << guardID << " (" << temp->name << "):" << endl;
                for (const auto& record : temp->attendance) {
                    cout << "Date: " << record.date << ", Day: " << record.day 
                         << ", Status: " << (record.isPresent ? "Present" : "Absent") << endl;
                }
                return;
            }
            temp = temp->next;
        }
        cout << "Guard ID not found." << endl;
    }

    void displayMonthlyAttendance() {
        cout << "--- Guard Attendance for Full Month ---" << endl;
        Guard* temp = head;
        while (temp) {
            cout << "Guard Name: " << temp->name << " - Attendance Records: " << endl;
            for (const auto& record : temp->attendance) {
                cout << "Date: " << record.date << ", Day: " << record.day 
                     << ", Status: " << (record.isPresent ? "Present" : "Absent") << endl;
            }
            temp = temp->next;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void viewPerformanceReports() {
        if (!head) {
            cout << "No guards available." << endl;
            return;
        }
        cout << "--- Performance Reports ---" << endl;
        Guard* temp = head;
        while (temp) {
            cout << "Guard ID: " << temp->id 
                 << ", Name: " << temp->name 
                 << ", Performance Rating: " << temp->performanceRating << endl;
            temp = temp->next;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void guardOfTheMonth() {
        if (!head) {
            cout << "No guards available." << endl;
            return;
        }
        Guard* topGuard = head;
        Guard* temp = head->next;
        while (temp) {
            if (temp->performanceRating > topGuard->performanceRating) {
                topGuard = temp;
            }
            temp = temp->next;
        }
        cout << "Guard of the Month: " << topGuard->name 
             << " (ID: " << topGuard->id 
             << ", Performance Rating: " << topGuard->performanceRating << ")" << endl;
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void topPerformingGuards(int N) {
        if (!head) {
            cout << "No guards available." << endl;
            return;
        }
        vector<Guard*> guards;
        Guard* temp = head;
        while (temp) {
            guards.push_back(temp);
            temp = temp->next;
        }

        sort(guards.begin(), guards.end(), [](Guard* a, Guard* b) {
            return a->performanceRating > b->performanceRating;
        });

        cout << "--- Top " << N << " Performing Guards ---" << endl;
        for (int i = 0; i < N && i < guards.size(); ++i) {
            cout << "Guard ID: " << guards[i]->id 
                 << ", Name: " << guards[i]->name 
                 << ", Performance Rating: " << guards[i]->performanceRating << endl;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void removeGuard(int guardID) {
        Guard* temp = head;
        Guard* prev = nullptr;

        while (temp) {
            if (temp->id == guardID) {
                if (prev) {
                    prev->next = temp->next;
                } else {
                    head = temp->next; // Remove head
                }
                delete temp;
                cout << "Guard ID " << guardID << " has been removed." << endl;
                return;
            }
            prev = temp;
            temp = temp->next;
        }
        cout << "Guard ID not found." << endl;
    }

    void updateGuard(int guardID, string name, string contact, string shift, bool available, int rating, double salary, string weapon, int uniformItems, string cnic) {
        Guard* temp = head;
        while (temp) {
            if (temp->id == guardID) {
                temp->name = name;
                temp->contact = contact;
                temp->shiftPreference = shift;
                temp->availability = available;
                temp->performanceRating = rating;
                temp->salary = salary;
                temp->weapon = weapon;
                temp->uniformItems = uniformItems;
                temp->cnic = cnic;
                cout << "Guard ID " << guardID << " has been updated." << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "Guard ID not found." << endl;
    }

    void searchGuardByID(int guardID) {
        Guard* temp = head;
        while (temp) {
            if (temp->id == guardID) {
                cout << "Guard ID: " << temp->id 
                     << ", Name: " << temp->name 
                     << ", Contact: " << temp->contact
                     << ", Shift: " << temp->shiftPreference 
                     << ", Available: " << (temp->availability ? "Yes" : "No")
                     << ", Rating: " << temp->performanceRating 
                     << ", Salary: " << temp->salary 
                     << ", Weapon: " << temp->weapon 
                     << ", Uniform Items: " << temp->uniformItems 
                     << ", CNIC: " << temp->cnic << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "Guard ID not found." << endl;
    }

    void displayAttendanceByGuardID(int guardID) {
        Guard* temp = head;
        while (temp) {
            if (temp->id == guardID) {
                cout << "Attendance Records for Guard ID " << guardID << " (" << temp->name << "):" << endl;
                for (const auto& record : temp->attendance) {
                    cout << "Date: " << record.date << ", Day: " << record.day 
                         << ", Status: " << (record.isPresent ? "Present" : "Absent") << endl;
                }
                return;
            }
            temp = temp->next;
        }
        cout << "Guard ID not found." << endl;
    }

    void generateRevenueReport() {
        if (!head) {
            cout << "No guards available." << endl;
            return;
        }
        double totalRevenue = 0.0;
        cout << "--- Revenue Report ---" << endl;
        Guard* temp = head;
        while (temp) {
            totalRevenue += temp->salary; // Assuming salary is the revenue generated by each guard
            cout << "Guard ID: " << temp->id 
                 << ", Name: " << temp->name 
                 << ", Salary: " << temp->salary << endl;
            temp = temp->next;
        }
        cout << "Total Revenue: " << totalRevenue << endl;
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }
};

struct Client {
    int id;
    string name;
    string contact;
    string requirements;
    int priorityLevel;
    bool isVIP;
    Client* next;
};

class ClientManagement {
public:
    Client* head;

    ClientManagement() { head = nullptr; }

    void addClient(int id, string name, string contact, string req, int priority, bool vip = false) {
        Client* newClient = new Client{id, name, contact, req, priority, vip, nullptr};
        if (!head) {
            head = newClient;
        } else {
            Client* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newClient;
        }
    }

    void displayClientData() {
        if (!head) {
            cout << "No clients available." << endl;
            return;
        }
        cout << "\n--- Client Data ---" << endl;
        cout << left << setw(10) << "Client ID" 
             << setw(20) << "Name" 
             << setw(15) << "Contact" 
             << setw(25) << "Requirements" 
             << setw(15) << "Priority" 
             << setw(10) << "VIP" << endl;
        cout << string(100, '-') << endl;

        Client* temp = head;
        while (temp) {
            cout << left << setw(10) << temp->id 
                 << setw(20) << temp->name 
                 << setw(15) << temp->contact 
                 << setw(25) << temp->requirements 
                 << setw(15) << temp->priorityLevel 
                 << setw(10) << (temp->isVIP ? "Yes" : "No") << endl;
            temp = temp->next;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void saveToFile(const string& filename) {
        ofstream file(filename);
        Client* temp = head;
        while (temp) {
            file << temp->id << "," << temp->name << "," << temp->contact << "," << temp->requirements << "," 
                 << temp->priorityLevel << "," << temp->isVIP << endl;
            temp = temp->next;
        }
        file.close();
    }

    void loadFromFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Could not open the file!" << endl;
            return;
        }

        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            Client* newClient = new Client();
            string isVIP;

            getline(ss, isVIP, ',');
            newClient->id = stoi(isVIP);
            getline(ss, newClient->name, ',');
            getline(ss, newClient->contact, ',');
            getline(ss, newClient->requirements, ',');
            getline(ss, isVIP, ',');
            newClient->priorityLevel = stoi(isVIP);
            getline(ss, isVIP, ',');
            newClient->isVIP = (isVIP == "1");

            // Add to linked list
            if (!head) {
                head = newClient;
            } else {
                Client* temp = head;
                while (temp->next) {
                    temp = temp->next;
                }
                temp->next = newClient;
            }
        }
        file.close();
    }
};

struct Request {
    int requestID;
    int clientID;
    string requestDetails;
    bool isEmergency;
    Request* next;
};

class RequestHandling {
public:
    Request* front;
    Request* rear;
    vector<Request*> requestHistory;

    RequestHandling() {
        front = rear = nullptr;
    }

    void addRequest(int id, int clientID, string details, bool isEmergency = false) {
        Request* newRequest = new Request{id, clientID, details, isEmergency, nullptr};
        if (!rear) {
            front = rear = newRequest;
        } else {
            rear->next = newRequest;
            rear = newRequest;
        }
        cout << "Request added successfully." << endl;
    }

    Request* processRequest() {
        if (!front) {
            cout << "No pending requests to process." << endl;
            return nullptr;
        }
        Request* processedRequest = front;
        front = front->next;
        if (!front) {
            rear = nullptr;
        }
        requestHistory.push_back(processedRequest);
        cout << "Processed Request ID: " << processedRequest->requestID << endl;
        return processedRequest;
    }

    void displayRequests() {
        if (!front) {
            cout << "No pending requests." << endl;
            return;
        }
        cout << "\n--- Pending Requests ---" << endl;
        Request* temp = front;
        while (temp) {
            cout << "Request ID: " << temp->requestID << ", Client ID: " << temp->clientID
                 << ", Details: " << temp->requestDetails 
                 << ", Emergency: " << (temp->isEmergency ? "Yes" : "No") << endl;
            temp = temp->next;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void displayRequestHistory() {
        if (requestHistory.empty()) {
            cout << "No request history available." << endl;
            return;
        }
        cout << "--- Request History ---" << endl;
        for (const auto& req : requestHistory) {
            cout << "Request ID: " << req->requestID << ", Client ID: " << req->clientID
                 << ", Details: " << req->requestDetails 
                 << ", Emergency: " << (req->isEmergency ? "Yes" : "No") << endl;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }

    void saveToFile(const string& filename) {
        ofstream file(filename);
        Request* temp = front;
        while (temp) {
            file << temp->requestID << "," << temp->clientID << "," << temp->requestDetails << "," 
                 << temp->isEmergency << endl;
            temp = temp->next;
        }
        file.close();
    }

    void loadFromFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Could not open the file!" << endl;
            return;
        }

        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            Request* newRequest = new Request();
            string isEmergency;

            getline(ss, isEmergency, ',');
            newRequest->requestID = stoi(isEmergency);
            getline(ss, isEmergency, ',');
            newRequest->clientID = stoi(isEmergency);
            getline(ss, newRequest->requestDetails, ',');
            getline(ss, isEmergency, ',');
            newRequest->isEmergency = (isEmergency == "1");

            // Add to queue
            if (!rear) {
                front = rear = newRequest;
            } else {
                rear->next = newRequest;
                rear = newRequest;
            }
        }
        file.close();
    }
};

class Graph {
private:
    map<string, list<string>> adjList;

public:
    void addLocation(const string& clientName, const string& location) {
        adjList[clientName].push_back(location);
    }

    void addRoute(const string& from, const string& to) {
        adjList[from].push_back(to);
        adjList[to].push_back(from);
    }

    void displayRoutes() {
        cout << "--- Client Locations and Routes ---" << endl;
        for (const auto& pair : adjList) {
            cout << "Client: " << pair.first << " -> Locations: ";
            for (const auto& location : pair.second) {
                cout << location << " ";
            }
            cout << endl;
        }
        // Pause for user to see the output
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }
};

// Function to clear the console
void clearConsole() {
#ifdef _WIN32
    system("cls"); // For Windows
#else
    system("clear"); // For Unix/Linux
#endif
}

int main() {
    GuardManagement gm;
    ClientManagement cm;
    RequestHandling requestHandler;
    Graph clientGraph;

    // Load data from files
    gm.loadFromFile("guards.txt");
    cm.loadFromFile("clients.txt");
    requestHandler.loadFromFile("requests.txt");
    gm.loadAttendanceFromFile(); // Load attendance records from file

    int mainChoice, subChoice;

    do {
        clearConsole(); // Clear console at the start of the main menu
        cout << "\n\t\t\t\t\t\t\t\t--- Chagai Security Guard Management System ---" << endl;
        cout << "1. Guards\n2. Clients\n3. Requests\n4. Attendance\n5. Exit\n";
        cout << "Enter your choice: ";
        cin >> mainChoice;

        switch (mainChoice) {
            case 1: // Guards
                do {
                    clearConsole(); // Clear console at the start of the guard management menu
                    cout << "\n\t\t\t\t\t\t\t\t--- Guard Management ---" << endl;
                    cout << "1. Add Guard\n2. View Guards\n3. Schedule Shift\n4. Mark Guard Attendance\n5. Update Guard Performance\n6. Remove Guard\n7. Update Guard Information\n8. Search Guard by ID\n9. Display Attendance by Guard ID\n10. View Performance Reports\n11. Guard of the Month\n12. Top Performing Guards\n13. Generate Revenue Report\n14. Save Guards to File\n15. Search Monthly Attendance by Guard ID\n16. Back to Main Menu\n";
                    cout << "Enter your choice: ";
                    cin >> subChoice;

                    switch (subChoice) {
                        case 1: {
                            int id, rating, uniformItems;
                            double salary;
                            string name, contact, shift, weapon, cnic;
                            bool available;
                            cout << "Enter Guard ID: ";
                            cin >> id;
                            cout << "Enter Name: ";
                            cin.ignore();
                            getline(cin, name);
                            cout << "Enter Contact: ";
                            getline(cin, contact);
                            cout << "Enter Shift Preference (Morning, Evening, Night): ";
                            getline(cin, shift);
                            cout << "Enter Availability (1 for Yes, 0 for No): ";
                            cin >> available;
                            cout << "Enter Performance Rating (1-5): ";
                            cin >> rating;
                            cout << "Enter Salary: ";
                            cin >> salary;
                            cout << "Enter Weapon: ";
                            cin.ignore();
                            getline(cin, weapon);
                            cout << "Enter Number of Uniform Items: ";
                            cin >> uniformItems;
                            cout << "Enter CNIC: ";
                            cin.ignore();
                            getline(cin, cnic);
                            gm.addGuard(id, name, contact, shift, available, rating, salary, weapon, uniformItems, cnic);
                            break;
                        }
                        case 2:
                            gm.displayGuardData();
                            break;
                        case 3: {
                            string shift;
                            cout << "Enter Shift (Morning, Evening, Night): ";
                            cin >> shift;
                            gm.scheduleShifts(shift);
                            break;
                        }
                        case 4: {
                            int id;
                            bool isPresent;
                            cout << "Enter Guard ID: ";
                            cin >> id;
                            cout << "Enter Attendance (1 for Present, 0 for Absent): ";
                            cin >> isPresent;
                            gm.markAttendance(id, isPresent);
                            break;
                        }
                        case 5: {
                            int id, rating;
                            cout << "Enter Guard ID: ";
                            cin >> id;
                            cout << "Enter Performance Rating (1-5): ";
                            cin >> rating;
                            gm.updatePerformance(id, rating);
                            break;
                        }
                        case 6: {
                            int id;
                            cout << "Enter Guard ID to remove: ";
                            cin >> id;
                            gm.removeGuard(id);
                            break;
                        }
                        case 7: {
                            int id, rating, uniformItems;
                            double salary;
                            string name, contact, shift, weapon, cnic;
                            bool available;
                            cout << "Enter Guard ID to update: ";
                            cin >> id;
                            cout << "Enter New Name: ";
                            cin.ignore();
                            getline(cin, name);
                            cout << "Enter New Contact: ";
                            getline(cin, contact);
                            cout << "Enter New Shift Preference (Morning, Evening, Night): ";
                            getline(cin, shift);
                            cout << "Enter New Availability (1 for Yes, 0 for No): ";
                            cin >> available;
                            cout << "Enter New Performance Rating (1-6): ";
                            cin >> rating;
                            cout << "Enter New Salary: ";
                            cin >> salary;
                            cout << "Enter New Weapon: ";
                            cin.ignore();
                            getline(cin, weapon);
                            cout << "Enter New Number of Uniform Items: ";
                            cin >> uniformItems;
                            cout << "Enter New CNIC: ";
                            cin.ignore();
                            getline(cin, cnic);
                            gm.updateGuard(id, name, contact, shift, available, rating, salary, weapon, uniformItems, cnic);
                            break;
                        }
                        case 8: {
                            int id;
                            cout << "Enter Guard ID to search: ";
                            cin >> id;
                            gm.searchGuardByID(id);
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        }
                        case 9: {
                            int id;
                            cout << "Enter Guard ID to display attendance: ";
                            cin >> id;
                            gm.displayAttendanceByGuardID(id);
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        }
                        case 10:
                            gm.viewPerformanceReports();
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        case 11:
                            gm.guardOfTheMonth();
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        case 12: {
                            int N;
                            cout << "Enter the number of top performing guards to display: ";
                            cin >> N;
                            gm.topPerformingGuards(N);
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        }
                        case 13:
                            gm.generateRevenueReport();
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        case 14:
                            gm.saveToFile("guards.txt");
                            cout << "Guards saved to file." << endl;
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        case 15: {
                            int id;
                            cout << "Enter Guard ID to search monthly attendance: ";
                            cin >> id;
                            gm.searchAttendanceByGuardID(id);
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        }
                        case 16:
                            break; // Back to main menu
                        default:
                            cout << "Invalid choice. Try again." << endl;
                    }
                } while (subChoice != 16);
                break;

            case 2: // Clients
                do {
                    clearConsole(); // Clear console at the start of the client management menu
                    cout << "\n\t\t\t\t\t\t\t\t--- Client Management ---" << endl;
                    cout << "1. Add Client\n2. View Clients\n3. Save Clients to File\n4. Back to Main Menu\n";
                    cout << "Enter your choice: ";
                    cin >> subChoice;

                    switch (subChoice) {
                        case 1: {
                            int id, priority;
                            string name, contact, req;
                            bool vip;
                            cout << "Enter Client ID: ";
                            cin >> id;
                            cout << "Enter Name: ";
                            cin.ignore();
                            getline(cin, name);
                            cout << "Enter Contact: ";
                            getline(cin, contact);
                            cout << "Enter Requirements: ";
                            getline(cin, req);
                            cout << "Enter Priority Level (1-5): ";
                            cin >> priority;
                            cout << "Is this client VIP? (1 for Yes, 0 for No): ";
                            cin >> vip;
                            cm.addClient(id, name, contact, req, priority, vip);
                            break;
                        }
                        case 2:
                            cm.displayClientData();
                            break;
                        case 3:
                            cm.saveToFile("clients.txt");
                            cout << "Clients saved to file." << endl;
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        case 4:
                            break; // Back to main menu
                        default:
                            cout << "Invalid choice. Try again." << endl;
                    }
                } while (subChoice != 4);
                break;

            case 3: // Requests
                do {
                    clearConsole(); // Clear console at the start of the request management menu
                    cout << "\n\t\t\t\t\t\t\t\t--- Request Management ---" << endl;
                    cout << "1. Add Request\n2. Process Request\n3. View Requests\n4. Save Requests to File\n5. Back to Main Menu\n";
                    cout << "Enter your choice: ";
                    cin >> subChoice;

                    switch (subChoice) {
                        case 1: {
                            int reqID, clientID;
                            string details;
                            bool isEmergency;
                            cout << "Enter Request ID: ";
                            cin >> reqID;
                            cout << "Enter Client ID: ";
                            cin >> clientID;
                            cout << "Enter Request Details: ";
                            cin.ignore();
                            getline(cin, details);
                            cout << "Is this an emergency request? (1 for Yes, 0 for No): ";
                            cin >> isEmergency;
                            requestHandler.addRequest(reqID, clientID, details, isEmergency);
                            break;
                        }
                        case 2: {
                            Request* processedRequest = requestHandler.processRequest();
                            if (processedRequest) {
                                cout << "Processed Request: " << processedRequest->requestID << " for Client " << processedRequest->clientID << endl;
                                delete processedRequest;
                            }
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        }
                        case 3:
                            requestHandler.displayRequests();
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        case 4:
                            requestHandler.saveToFile("requests.txt");
                            cout << "Requests saved to file." << endl;
                            cout << "\nPress Enter to continue...";
                            cin.ignore();
                            cin.get();
                            break;
                        case 5:
                            break; // Back to main menu
                        default:
                            cout << "Invalid choice. Try again." << endl;
                    }
                } while (subChoice != 5);
                break;

            case 4: // Attendance
                do {
                    clearConsole(); // Clear console at the start of the attendance management menu
                    cout << "\n\t\t\t\t\t\t\t\t--- Attendance Management ---" << endl;
                    cout << "1. Display Monthly Attendance\n2. Back to Main Menu\n";
                    cout << "Enter your choice: ";
                    cin >> subChoice;

                    switch (subChoice) {
                        case 1:
                            gm.displayMonthlyAttendance();
                            break;
                        case 2:
                            break; // Back to main menu
                        default:
                            cout << "Invalid choice. Try again." << endl;
                    }
                } while (subChoice != 2);
                break;

            case 5:
                cout << "Exiting program." << endl;
                break;

            default:
                cout << "Invalid choice. Try again." << endl;
        }
    } while (mainChoice != 5);

    return 0;
}	