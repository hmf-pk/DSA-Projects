#include <iostream>
#include <queue>  // For Queue
#include <stack>  // For Stack
using namespace std;

// Book structure to store details of each book
struct Book {
    int id;
    string title;
    string author;
    bool isAvailable;
    
    Book() : id(-1), title(""), author(""), isAvailable(false) {}

    Book(int i, string t, string a, bool available) {
        id = i;
        title = t;
        author = a;
        isAvailable = available;
    }
};

// Doubly Linked List Node for Books
struct BookNode {
    Book book;
    BookNode* next;
    BookNode* prev;
    
    BookNode(Book b) : book(b), next(nullptr), prev(nullptr) {}
};

// Library class to manage books using Linked List, Queue and Stack
class Library {
private:
    BookNode* head;  // Head of the doubly linked list
    BookNode* tail;  // Tail of the doubly linked list
    stack<string> actions;  // Stack for undo functionality
    queue<string> actionHistory;  // Queue to track action history (FIFO)

public:
    Library() : head(nullptr), tail(nullptr) {}

    // Add a book to the library
    void addBook(Book book) {
        BookNode* newNode = new BookNode(book);
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    // Show all books in the library (Doubly Linked List based approach)
    void showAllBooks() {
        BookNode* temp = head;
        cout << "Available Books: " << endl;
        while (temp != nullptr) {
            if (temp->book.isAvailable) {
                cout << "Book ID: " << temp->book.id << ", Title: " << temp->book.title << ", Author: " << temp->book.author << endl;
            }
            temp = temp->next;
        }
    }

    // Issue a book
    void issueBook(int bookId) {
        BookNode* temp = head;
        while (temp != nullptr) {
            if (temp->book.id == bookId && temp->book.isAvailable) {
                temp->book.isAvailable = false;
                actions.push("issue " + to_string(bookId));  // Track the action for undo
                actionHistory.push("issue " + to_string(bookId));  // FIFO for history
                cout << "Book with ID " << bookId << " has been issued." << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "This book is either not available or doesn't exist!" << endl;
    }

    // Return a book
    void returnBook(int bookId) {
        BookNode* temp = head;
        while (temp != nullptr) {
            if (temp->book.id == bookId && !temp->book.isAvailable) {
                temp->book.isAvailable = true;
                actions.push("return " + to_string(bookId));  // Track the action for undo
                actionHistory.push("return " + to_string(bookId));  // FIFO for history
                cout << "Book with ID " << bookId << " has been returned." << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "This book wasn't issued!" << endl;
    }

    // Search a book by ID
    void searchBook(int bookId) {
        BookNode* temp = head;
        while (temp != nullptr) {
            if (temp->book.id == bookId) {
                cout << "Book found: " << temp->book.title << ", Author: " << temp->book.author << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "Book not found." << endl;
    }

    // Undo the last action
    void undoLastAction() {
        if (!actions.empty()) {
            string lastAction = actions.top();
            actions.pop();

            int bookId = stoi(lastAction.substr(lastAction.find(" ") + 1));  // Extract book ID

            if (lastAction.find("issue") != string::npos) {
                // Undo issue
                BookNode* temp = head;
                while (temp != nullptr) {
                    if (temp->book.id == bookId) {
                        temp->book.isAvailable = true;
                        cout << "Undo: Book with ID " << bookId << " is now available again." << endl;
                        return;
                    }
                    temp = temp->next;
                }
            } else if (lastAction.find("return") != string::npos) {
                // Undo return
                BookNode* temp = head;
                while (temp != nullptr) {
                    if (temp->book.id == bookId) {
                        temp->book.isAvailable = false;
                        cout << "Undo: Book with ID " << bookId << " is now issued again." << endl;
                        return;
                    }
                    temp = temp->next;
                }
            }
        } else {
            cout << "No actions to undo!" << endl;
        }
    }

    // Display action history using Queue (FIFO)
    void displayActionHistory() {
        cout << "Action History (FIFO): " << endl;
        while (!actionHistory.empty()) {
            cout << actionHistory.front() << endl;
            actionHistory.pop();
        }
    }
};

int main() {
    Library library;

    // Adding 10 sample books to the library
    library.addBook(Book(1, "The Alchemist", "Paulo Coelho", true));
    library.addBook(Book(2, "The Catcher in the Rye", "J.D. Salinger", true));
    library.addBook(Book(3, "1984", "George Orwell", true));
    library.addBook(Book(4, "To Kill a Mockingbird", "Harper Lee", true));
    library.addBook(Book(5, "Pride and Prejudice", "Jane Austen", true));
    library.addBook(Book(6, "Moby Dick", "Herman Melville", true));
    library.addBook(Book(7, "The Great Gatsby", "F. Scott Fitzgerald", true));
    library.addBook(Book(8, "Crime and Punishment", "Fyodor Dostoevsky", true));
    library.addBook(Book(9, "Brave New World", "Aldous Huxley", true));
    library.addBook(Book(10, "War and Peace", "Leo Tolstoy", true));

    int choice, bookId;

    while (true) {
        cout << "\nLibrary Management System" << endl;
        cout << "1. Show All Books" << endl;
        cout << "2. Issue Book" << endl;
        cout << "3. Return Book" << endl;
        cout << "4. Search Book by ID" << endl;
        cout << "5. Undo Last Action" << endl;
        cout << "6. Display Action History" << endl;
        cout << "7. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                library.showAllBooks();
                break;
            case 2:
                cout << "Enter book ID to issue: ";
                cin >> bookId;
                library.issueBook(bookId);
                break;
            case 3:
                cout << "Enter book ID to return: ";
                cin >> bookId;
                library.returnBook(bookId);
                break;
            case 4:
                cout << "Enter book ID to search: ";
                cin >> bookId;
                library.searchBook(bookId);
                break;
            case 5:
                library.undoLastAction();
                break;
            case 6:
                library.displayActionHistory();
                break;
            case 7:
                cout << "Exiting..." << endl;
                return 0;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    }
    return 0;
}
