#include <bits/stdc++.h>
using namespace std;

// Global data structures
unordered_map<string, vector<int>> invertedIndex; // Maps words to document IDs
vector<pair<string, string>> documents;           // Stores all documents (content and link)

// Function to normalize text to lowercase for uniform indexing
string normalizeWord(const string &word) {
    string normalized = word;
    transform(normalized.begin(), normalized.end(), normalized.begin(), ::tolower);
    return normalized;
}

// Function for fuzzy search
int fuzzySearch(const string &a, const string &b) {
    int m = a.size(), n = b.size();
    vector<vector<int>> dp(m + 1, vector<int>(n + 1));

    for (int i = 0; i <= m; ++i)
        dp[i][0] = i;
    for (int j = 0; j <= n; ++j)
        dp[0][j] = j;

    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (a[i - 1] == b[j - 1])
                dp[i][j] = dp[i - 1][j - 1];
            else
                dp[i][j] = 1 + min({dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]});
        }
    }

    return dp[m][n];
}

// Function to preprocess and index all documents
void createInvertedIndex() {
    invertedIndex.clear(); // Clear the existing index for re-indexing
    cout << "\nCreating Inverted Index...\n";
    for (int docID = 0; docID < documents.size(); ++docID) {
        string doc = documents[docID].first; // Only index the content
        istringstream iss(doc);
        string word;
        while (iss >> word) {
            word = normalizeWord(word);
            invertedIndex[word].push_back(docID);
        }
    }
    cout << "Inverted Index successfully created.\n";
}

// Function to fetch relevant documents based on user query
vector<int> querySearch(const string &query) {
    unordered_map<int, int> docFrequency; // Maps document IDs to query word matches
    istringstream iss(query);
    string word;

    cout << "\nProcessing query: \"" << query << "\"\n";
    while (iss >> word) {
        word = normalizeWord(word);

        // Perform fuzzy matching with indexed words
        for (const auto &entry : invertedIndex) {
            if (fuzzySearch(word, entry.first) <= 2) { // Allow a max distance of 2
                for (int docID : entry.second) {
                    docFrequency[docID]++;
                }
            }
        }
    }

    // Rank documents by their frequency (basic relevance ranking)
    priority_queue<pair<int, int>> rankedDocs; // (frequency, docID)
    for (const auto &entry : docFrequency) {
        rankedDocs.push({entry.second, entry.first});
    }

    // Extract top-K results
    vector<int> results;
    int topK = 5; // Limit to top 5 results
    while (!rankedDocs.empty() && topK--) {
        results.push_back(rankedDocs.top().second);
        rankedDocs.pop();
    }

    return results;
}

// Function to display the results of a query
void displayResults(const vector<int> &results) {
    if (results.empty()) {
        cout << "No relevant documents found for the query.\n";
    } else {
        cout << "\nTop Search Results:\n";
        for (int rank = 0; rank < results.size(); ++rank) {
            int docID = results[rank];
            cout << rank + 1 << ". Document " << docID + 1 << ": \"" << documents[docID].first 
                 << "\"\n   Link: " << documents[docID].second << "\n";
        }

        // Option to open a link
        cout << "\nEnter the result number to open the link (or 0 to skip): ";
        int choice;
        cin >> choice;
        if (choice > 0 && choice <= results.size()) {
            int docID = results[choice - 1];
            string command = "";

#ifdef _WIN32
#endif

            system(command.c_str());
        }
    }
}

// Function to load data from file
void loadDataFromFile() {
    ifstream inFile("data.txt");
    if (!inFile) {
        cerr << "No existing data found. Starting fresh.\n";
        return;
    }

    documents.clear();
    string line;
    while (getline(inFile, line)) {
        size_t sepPos = line.find('|');
        if (sepPos != string::npos) {
            string content = line.substr(0, sepPos);
            string link = line.substr(sepPos + 1);
            documents.emplace_back(content, link);
        }
    }
    inFile.close();
    createInvertedIndex();
}

// Function to save data to file
void saveDataToFile() {
    ofstream outFile("data.txt");
    if (!outFile) {
        cerr << "Error saving data to file.\n";
        return;
    }

    for (const auto &doc : documents) {
        outFile << doc.first << "|" << doc.second << "\n";
    }
    outFile.close();
}

// Function to add a new document
void addDocument(const string &newDoc, const string &link) {
    documents.emplace_back(newDoc, link);
    cout << "\nNew document added: \"" << newDoc << "\" with link: " << link << "\n";
    saveDataToFile();
    createInvertedIndex(); // Rebuild the inverted index
}

// Function to display all documents
void displayAllDocuments() {
    cout << "\nAll Documents:\n";
    for (int i = 0; i < documents.size(); ++i) {
        cout << "Document " << i + 1 << ": \"" << documents[i].first 
             << "\"\n   Link: " << documents[i].second << "\n";
    }
}

int main() {
    loadDataFromFile();
while (true) {
        cout << "\n--- Fuzzy Search Engine ---\n";
        cout << "1. Search Query\n";
        cout << "2. Add New Document\n";
        cout << "3. Display All Documents\n";
        cout << "4. Exit\n";
        cout << "Choose an option: ";

        int choice;
        cin >> choice;
        cin.ignore(); // Ignore trailing newline
        if (choice == 1) {
            cout << "\nEnter your search query: ";
            string query;
            getline(cin, query);
            vector<int> results = querySearch(query);
            displayResults(results);
        } else if (choice == 2) {
            cout << "\nEnter the new document text: ";
            string newDoc;
            getline(cin, newDoc);
            cout << "Enter the link for the document: ";
            string link;
            getline(cin, link);
            addDocument(newDoc, link);
        } else if (choice == 3) {
            displayAllDocuments();
        } else if (choice == 4) {
            cout << "\nExiting Search Engine. Goodbye!\n";
            break;
        } else {
            cout << "\nInvalid option. Please try again.\n";
        }
}
    return 0;
}
    